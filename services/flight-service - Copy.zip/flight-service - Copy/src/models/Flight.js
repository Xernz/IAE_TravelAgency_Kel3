const db = require('../config/db');
const { paginateQuery, paginatedResponse } = require('../../../utils/pagination');

const Flight = {
  // Decrease available seats for a flight and date
  decreaseAvailability: (flightId, date, quantity, callback) => {
    db.query(
      'UPDATE FlightAvailability SET available_seats = available_seats - ? WHERE flight_id = ? AND travel_date = ? AND available_seats >= ?;',
      [quantity, flightId, date, quantity],
      (err, result) => {
        if (err) return callback(err);
        callback(null, result);
      }
    );
  },
  // Increase available seats for a flight and date
  increaseAvailability: (flightId, date, quantity, callback) => {
    db.query(
      'UPDATE FlightAvailability SET available_seats = available_seats + ? WHERE flight_id = ? AND travel_date = ?;',
      [quantity, flightId, date],
      (err, result) => {
        if (err) return callback(err);
        callback(null, result);
      }
    );
  },

  search: (params, callback) => {
    const { origin_city, destination_city, date } = params;
    let sql = `SELECT * FROM Flights WHERE 1=1`;
    const values = [];
    if (origin_city) { sql += ' AND origin_city = ?'; values.push(origin_city); }
    if (destination_city) { sql += ' AND destination_city = ?'; values.push(destination_city); }
    if (date) { sql += ' AND DATE(departure_time) = ?'; values.push(date); }
    db.query(sql, values, (err, results) => callback(err, results));
  },
  
  listAll: (params, callback) => {
    // Count total flights for pagination info
    db.query('SELECT COUNT(*) as total FROM Flights', [], (err, countResult) => {
      if (err) return callback(err);
      
      const totalItems = countResult[0].total;
      const baseSql = `SELECT * FROM Flights ORDER BY departure_time`;
      
      // Apply pagination if page and limit parameters exist
      if (params.page || params.limit) {
        const { sql, values, pagination } = paginateQuery(baseSql, params);
        
        db.query(sql, values, (err, results) => {
          if (err) return callback(err);
          
          const paginatedData = paginatedResponse(results, pagination, totalItems);
          callback(null, paginatedData);
        });
      } else {
        // No pagination requested, return all results
        db.query(baseSql, [], (err, results) => {
          callback(err, { data: results, pagination: null });
        });
      }
    });
  },
  
  filter: (params, callback) => {
    const { 
      origin_city, destination_city, origin_code, destination_code,
      airline_code, airline_name, flight_class, departure_date,
      min_price, max_price, sort_by, sort_order, page, limit
    } = params;
    
    let sql = `
      SELECT f.*, fp.price, fp.currency 
      FROM Flights f
      LEFT JOIN FlightPricing fp ON f.id = fp.flight_id
      WHERE 1=1
    `;
    
    const values = [];
    
    if (origin_city) { sql += ' AND f.origin_city = ?'; values.push(origin_city); }
    if (destination_city) { sql += ' AND f.destination_city = ?'; values.push(destination_city); }
    if (origin_code) { sql += ' AND f.origin_code = ?'; values.push(origin_code); }
    if (destination_code) { sql += ' AND f.destination_code = ?'; values.push(destination_code); }
    if (airline_code) { sql += ' AND f.airline_code = ?'; values.push(airline_code); }
    if (airline_name) { sql += ' AND f.airline_name LIKE ?'; values.push(`%${airline_name}%`); }
    if (flight_class) { sql += ' AND f.flight_class = ?'; values.push(flight_class); }
    if (departure_date) { sql += ' AND DATE(f.departure_time) = ?'; values.push(departure_date); }
    if (min_price) { sql += ' AND fp.price >= ?'; values.push(min_price); }
    if (max_price) { sql += ' AND fp.price <= ?'; values.push(max_price); }
    
    // Add sorting
    if (sort_by) {
      const validSortColumns = ['departure_time', 'arrival_time', 'price', 'airline_name'];
      const sortColumn = validSortColumns.includes(sort_by) ? sort_by : 'departure_time';
      const order = sort_order && sort_order.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
      
      if (sortColumn === 'price') {
        sql += ` ORDER BY fp.${sortColumn} ${order}`;
      } else {
        sql += ` ORDER BY ${sortColumn} ${order}`;
      }
    } else {
      sql += ' ORDER BY f.departure_time ASC';
    }
    
    // Count total flights matching the filter for pagination info
    const countSql = sql.replace('SELECT f.*, fp.price, fp.currency', 'SELECT COUNT(*) as total');
    db.query(countSql, values, (err, countResult) => {
      if (err) return callback(err);
      
      const totalItems = countResult[0].total;
      
      // Apply pagination if page and limit parameters exist
      if (page || limit) {
        const { sql: paginatedSql, values: paginationValues, pagination } = paginateQuery(sql, { page, limit });
        
        // Combine filter values with pagination values
        const combinedValues = [...values, ...paginationValues];
        
        db.query(paginatedSql, combinedValues, (err, results) => {
          if (err) return callback(err);
          
          const paginatedData = paginatedResponse(results, pagination, totalItems);
          callback(null, paginatedData);
        });
      } else {
        // No pagination requested, return all results
        db.query(sql, values, (err, results) => {
          callback(err, { data: results, pagination: null });
        });
      }
    });
  },
  getById: (id, callback) => {
    db.query('SELECT * FROM Flights WHERE id = ?', [id], (err, results) => callback(err, results[0]));
  },
  getAvailability: (flightId, date, callback) => {
    db.query('SELECT * FROM FlightAvailability WHERE flight_id = ? AND travel_date = ?', [flightId, date], (err, results) => callback(err, results[0]));
  },
  getPricing: (flightId, date, callback) => {
    db.query('SELECT * FROM FlightPricing WHERE flight_id = ? AND travel_date = ?', [flightId, date], (err, results) => callback(err, results[0]));
  }
};

module.exports = Flight;
